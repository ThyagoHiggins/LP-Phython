
telefone = int(input('Informe seu telefone (xxxxxxxxx):  '))
if len(telefone)!=9:
   print(telefone)