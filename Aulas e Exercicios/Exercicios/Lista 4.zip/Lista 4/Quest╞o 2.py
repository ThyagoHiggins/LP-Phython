
nome = str(input('Por gentileza informe seu nome:  ')).upper()
print(nome[::-1])
